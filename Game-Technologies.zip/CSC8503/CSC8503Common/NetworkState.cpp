#include "NetworkState.h"

using namespace NCL;
using namespace CSC8503;

NetworkState::NetworkState()	{
	stateID = 0;
}

NetworkState::~NetworkState()	{
}