#include "QuadTree.h"
#include "../../Common/Vector3.h"
using namespace NCL;
